# Handoff: Products page — brand logos

Target codebase: `lspuia/white-walls-dev-2027` (Next.js + Tailwind), page `src/app/products/page.tsx`.

## Overview
The Products index now shows each brand's logo on its tile. Brand tiles drop the `PlaceholderImage` and instead open with a uniform white logo card. Category tiles are unchanged. Everything else on the page (intro, groups, ShopSocial, header/footer) is unchanged.

## About the design files
`Products Page.dc.html` is a **design reference in HTML** — a prototype of the intended look, not production code. Recreate the change in the existing Next.js page using its established patterns (Tailwind classes, `@/lib/products`, existing components). This is a **high-fidelity** design: match it exactly.

## The change, precisely

### 1. Assets
Copy `assets/brands/*.webp` (5 files) into the repo at `public/brand/products/` (or your preferred public path):
hettich.webp, brassage.webp, hafele.webp, veneto.webp, vmzinc.webp.
Add a `logo` field to each `kind: "brand"` entry in `src/lib/products.ts`, e.g. `logo: "/brand/products/hettich.webp"`.

Note: the Häfele file has a built-in black background (their lockup) — it renders as a black block inside the white card; this is accepted. If the owners supply a transparent version later, swap the file only.

### 2. Brand tile (kind === "brand")
Replace `<PlaceholderImage ratio="3/4" …>` with a logo card:

- Card: `aspect-ratio: 3/2`, full tile width, background `#FFFFFF` (pure white, deliberately distinct from the bone page ground), border `1px solid var(--color-rule)`, **no border-radius** (square corners, hard rule), no shadow, padding `32px`, flex, centered both axes.
- Logo `<img>`: `max-height: 72px; width: auto; max-width: 100%; object-fit: contain`. Alt text `"{Brand} logo"`.
- Below the card, the existing text block is unchanged: gap 18px between card and text; name in Cormorant Garamond Light at `var(--text-service)`, hover → bronze; tagline caption in mute; teaser body in soft.

### 3. Category tile (kind === "category")
Unchanged — keeps `<PlaceholderImage ratio="3/4">`.

### 4. Grid
Unchanged from the current page: flex-wrap, justify-center, column-gap 34px, row-gap 52px, 3-across desktop (`basis calc((100%-68px)/3)`), 2 on tablet, 1 on mobile.

## Interactions
- Whole tile remains one `<Link>` to `/products/{slug}`; brand-name color transitions to bronze on hover (`transition-colors`, .2s). No new interactions, no animation on the card.

## Design tokens used (existing)
- `--color-rule` card border, `--color-ink` names, `--color-mute` taglines, `--color-soft` teasers, `--color-bronze` hover.
- New literal: `#FFFFFF` card ground (only place pure white is used).

## Optional variant (built as a tweak in the prototype, off by default)
Muted logos: `filter: grayscale(1) opacity(.72)` on the logo img. Not shipped on by default; implement only if the owners ask.

## Files
- `Products Page.dc.html` — the design reference (open in a browser).
- `assets/brands/*.webp` — the five brand logos, as supplied by the owners.

## Screenshots
- `screenshots/01-products-page.png` — top: header, title, intro, Brands grid with logo cards.
- `screenshots/02-products-page.png` — mid: Brands / Categories groups.
- `screenshots/03-products-page.png` — bottom: Categories, Follow the shop, footer.
